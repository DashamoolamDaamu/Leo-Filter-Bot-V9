#  @MrMNTG @MusammilN
#please give credits https://github.com/MN-BOTS/ShobanaFilterBot

import logging
from pyrogram.errors import InputUserDeactivated, UserNotParticipant, FloodWait, UserIsBlocked, PeerIdInvalid
from info import LONG_IMDB_DESCRIPTION, MAX_LIST_ELM
import asyncio
from pyrogram.types import Message, InlineKeyboardButton
from pyrogram import enums
from typing import Union
import re
import os
from datetime import datetime
from typing import List, Optional
from database.users_chats_db import db
from bs4 import BeautifulSoup
import requests
from urllib.parse import quote_plus

#  @MrMNTG @MusammilN
#please give credits https://github.com/MN-BOTS/ShobanaFilterBot
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

BTN_URL_REGEX = re.compile(
    r"(\[([^\[]+?)\]\((buttonurl|buttonalert):(?:/{0,2})(.+?)(:same)?\))"
)

IMDB_API_BASE = "https://mn-api-imdb.vercel.app/api/search"
HTTP_TIMEOUT = 10

BANNED = {}
SMART_OPEN = '“'
SMART_CLOSE = '”'
START_CHAR = ('\'', '"', SMART_OPEN)

# temp db for banned 
class temp(object):
    BANNED_USERS = []
    BANNED_CHATS = []
    ME = None
    CURRENT=int(os.environ.get("SKIP", 2))
    CANCEL = False
    MELCOW = {}
    U_NAME = None
    B_NAME = None
    SETTINGS = {}

#  @MrMNTG @MusammilN
#please give credits https://github.com/MN-BOTS/ShobanaFilterBot
from pyrogram.enums import ChatMemberStatus
from database.users_chats_db import db
from info import REQUEST_FSUB_MODE  # Import from your info.py

JOIN_REQUEST_USERS = {}

async def is_subscribed(user_id: int, client) -> bool:
    auth_channels = await db.get_auth_channels()
    if not auth_channels:
        return True  # No channels to check

    requested_channels = set()
    if REQUEST_FSUB_MODE:
        requested_channels = set(JOIN_REQUEST_USERS.get(user_id, set()))
        try:
            requested_channels.update(await db.get_join_user_channels(user_id))
        except Exception as e:
            logger.warning("Unable to load join request users from database: %s", e)

    for channel in auth_channels:
        is_member = False
        try:
            member = await client.get_chat_member(channel, user_id)
            if member.status in [
                ChatMemberStatus.MEMBER,
                ChatMemberStatus.ADMINISTRATOR,
                ChatMemberStatus.OWNER,
            ]:
                is_member = True
        except Exception:
            pass

        if is_member:
            continue  # Channel satisfied via membership/admin

        # If REQUEST_FSUB_MODE is enabled, also accept a pending join request
        if REQUEST_FSUB_MODE and channel in requested_channels:
            continue  # Channel satisfied via join request

        # Channel not satisfied by either condition
        return False

    return True

async def get_or_create_invite_link(client, channel: int, purpose: str, **kwargs) -> Optional[str]:
    cached_link = await db.get_invite_link(channel, purpose)
    if cached_link:
        return cached_link

    try:
        invite = await client.create_chat_invite_link(
            channel,
            name=kwargs.pop("name", "BotAccess"),
            **kwargs,
        )
    except Exception as e:
        logger.warning("Unable to create invite link for %s: %s", channel, e)
        return None

    await db.save_invite_link(channel, purpose, invite.invite_link)
    return invite.invite_link


async def get_chat_join_link(
    client,
    channel: int,
    purpose: str = "fsub",
    creates_join_request: Optional[bool] = None,
) -> Optional[str]:
    try:
        chat = await client.get_chat(int(channel))
        if chat.username:
            return f"https://t.me/{chat.username}"
    except Exception:
        pass

    join_request_mode = REQUEST_FSUB_MODE if creates_join_request is None else creates_join_request
    purpose_key = f"{purpose}:request" if join_request_mode else f"{purpose}:direct"
    return await get_or_create_invite_link(
        client,
        int(channel),
        purpose_key,
        creates_join_request=join_request_mode,
        name="BotAuthAccess",
    )


async def create_invite_links(client) -> dict:
    links = {}
    auth_channels = await db.get_auth_channels()
    for channel in auth_channels:
        link = await get_chat_join_link(client, int(channel), purpose="fsub")
        if link:
            links[channel] = link
    return links

#  @MrMNTG @MusammilN
#please give credits https://github.com/MN-BOTS/ShobanaFilterBot


def _get_json(url):
    response = requests.get(url, timeout=HTTP_TIMEOUT)
    response.raise_for_status()
    return response.json()


def search_imdb(query, page=1):
    search_url = f"{IMDB_API_BASE}?q={quote_plus(query)}&page={page}"
    data = _get_json(search_url)
    return {
        "results": data.get("Search") or [],
        "page": int(data.get("page") or page),
        "next_page": data.get("nextPage"),
        "total_results": int(data.get("totalResults") or 0),
    }


async def search_imdb_async(query, page=1):
    return await asyncio.to_thread(search_imdb, query, page)


async def get_poster(query, bulk=False, id=False, file=None):
    if not id:
        # https://t.me/GetTGLink/4183
        query = (query.strip()).lower()
        title = query
        year = re.findall(r'[1-2]\d{3}$', query, re.IGNORECASE)
        if year:
            year = list_to_str(year[:1])
            title = (query.replace(year, "")).strip()
        elif file is not None:
            year = re.findall(r'[1-2]\d{3}', file, re.IGNORECASE)
            if year:
                year = list_to_str(year[:1]) 
        else:
            year = None
        search_data = await search_imdb_async(title, page=1)
        movie_list = search_data.get("results") or []
        if not movie_list:
            return None
        if year:
            filtered = [m for m in movie_list if str(m.get("Year")) == str(year)]
            if not filtered:
                filtered = movie_list
        else:
            filtered = movie_list
        movie_list = [m for m in filtered if m.get("Type") in ["movie", "series", "tvseries"]] or filtered
        if bulk:
            return movie_list
        movieid = movie_list[0].get("imdbID")
    else:
        movieid = query

    details_url = f"{IMDB_API_BASE}?id={movieid}"
    movie = await asyncio.to_thread(_get_json, details_url)

    plot = movie.get("Plot") or ""
    if plot and len(plot) > 800:
        plot = plot[:800] + "..."

    return {
        'title': movie.get('Title'),
        'votes': "N/A",
        "aka": "N/A",
        "seasons": "N/A",
        "box_office": "N/A",
        'localized_title': movie.get('Title'),
        'kind': movie.get("Type", "movie"),
        "imdb_id": movie.get('imdbID'),
        "cast": movie.get("Stars", "N/A"),
        "runtime": movie.get("Runtime", "N/A"),
        "countries": "N/A",
        "certificates": "N/A",
        "languages": movie.get("Language", "N/A"),
        "director": movie.get("Director", "N/A"),
        "writer": movie.get("Writer", "N/A"),
        "producer": "N/A",
        "composer": "N/A",
        "cinematographer": "N/A",
        "music_team": "N/A",
        "distributors": "N/A",
        'release_date': movie.get("ReleaseDate") or movie.get("Year") or "N/A",
        'year': movie.get('Year'),
        'genres': movie.get("Genres", "N/A"),
        'poster': movie.get('Poster'),
        'plot': plot,
        'rating': str(movie.get("imdbRating", "N/A")),
        'url': f"https://www.imdb.com/title/{movieid}"
    }
# https://github.com/odysseusmax/animated-lamp/blob/2ef4730eb2b5f0596ed6d03e7b05243d93e3415b/bot/utils/broadcast.py#L37

async def broadcast_messages(user_id, message):
    try:
        await message.copy(chat_id=user_id)
        return True, "Success"
    except FloodWait as e:
        wait_for = getattr(e, "value", None) or getattr(e, "x", 0)
        await asyncio.sleep(int(wait_for) + 1)
        return await broadcast_messages(user_id, message)
    except InputUserDeactivated:
        await db.delete_user(int(user_id))
        logging.info(f"{user_id}-Removed from Database, since deleted account.")
        return False, "Deleted"
    except UserIsBlocked:
        logging.info(f"{user_id} -Blocked the bot.")
        return False, "Blocked"
    except PeerIdInvalid:
        await db.delete_user(int(user_id))
        logging.info(f"{user_id} - PeerIdInvalid")
        return False, "Deleted"
    except Exception as e:
        return False, "Error"

async def search_gagala(text):
    usr_agent = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/61.0.3163.100 Safari/537.36'
        }
    text = text.replace(" ", '+')
    url = f'https://www.google.com/search?q={text}'
    response = await asyncio.to_thread(requests.get, url, headers=usr_agent, timeout=HTTP_TIMEOUT)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    titles = soup.find_all( 'h3' )
    return [title.getText() for title in titles]


async def get_settings(group_id):
    settings = temp.SETTINGS.get(group_id)
    if not settings:
        settings = await db.get_settings(group_id)
        temp.SETTINGS[group_id] = settings
    return settings
    
async def save_group_settings(group_id, key, value):
    current = await get_settings(group_id)
    current[key] = value
    temp.SETTINGS[group_id] = current
    await db.update_settings(group_id, current)
    
def get_size(size):
    """Get size in readable format"""

    units = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB"]
    size = float(size)
    i = 0
    while size >= 1024.0 and i < len(units):
        i += 1
        size /= 1024.0
    return "%.2f %s" % (size, units[i])

def split_list(l, n):
    for i in range(0, len(l), n):
        yield l[i:i + n]  

def get_file_id(msg: Message):
    if msg.media:
        for message_type in (
            "photo",
            "animation",
            "audio",
            "document",
            "video",
            "video_note",
            "voice",
            "sticker"
        ):
            obj = getattr(msg, message_type)
            if obj:
                setattr(obj, "message_type", message_type)
                return obj

def extract_user(message: Message) -> Union[int, str]:
    """extracts the user from a message"""
    # https://github.com/SpEcHiDe/PyroGramBot/blob/f30e2cca12002121bad1982f68cd0ff9814ce027/pyrobot/helper_functions/extract_user.py#L7
    user_id = None
    user_first_name = None
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        user_first_name = message.reply_to_message.from_user.first_name

    elif len(message.command) > 1:
        if (
            len(message.entities) > 1 and
            message.entities[1].type == enums.MessageEntityType.TEXT_MENTION
        ):
           
            required_entity = message.entities[1]
            user_id = required_entity.user.id
            user_first_name = required_entity.user.first_name
        else:
            user_id = message.command[1]
            # don't want to make a request -_-
            user_first_name = user_id
        try:
            user_id = int(user_id)
        except ValueError:
            pass
    else:
        user_id = message.from_user.id
        user_first_name = message.from_user.first_name
    return (user_id, user_first_name)

def list_to_str(k):
    if not k:
        return "N/A"
    elif len(k) == 1:
        return str(k[0])
    elif MAX_LIST_ELM:
        k = k[:int(MAX_LIST_ELM)]
        return ' '.join(f'{elem}, ' for elem in k)
    else:
        return ' '.join(f'{elem}, ' for elem in k)

def last_online(from_user):
    time = ""
    if from_user.is_bot:
        time += "🤖 Bot :("
    elif from_user.status == enums.UserStatus.RECENTLY:
        time += "Recently"
    elif from_user.status == enums.UserStatus.LAST_WEEK:
        time += "Within the last week"
    elif from_user.status == enums.UserStatus.LAST_MONTH:
        time += "Within the last month"
    elif from_user.status == enums.UserStatus.LONG_AGO:
        time += "A long time ago :("
    elif from_user.status == enums.UserStatus.ONLINE:
        time += "Currently Online"
    elif from_user.status == enums.UserStatus.OFFLINE:
        time += from_user.last_online_date.strftime("%a, %d %b %Y, %H:%M:%S")
    return time


def split_quotes(text: str) -> List:
    if not any(text.startswith(char) for char in START_CHAR):
        return text.split(None, 1)
    counter = 1  # ignore first char -> is some kind of quote
    while counter < len(text):
        if text[counter] == "\\":
            counter += 1
        elif text[counter] == text[0] or (text[0] == SMART_OPEN and text[counter] == SMART_CLOSE):
            break
        counter += 1
    else:
        return text.split(None, 1)

    # 1 to avoid starting quote, and counter is exclusive so avoids ending
    key = remove_escapes(text[1:counter].strip())
    # index will be in range, or `else` would have been executed and returned
    rest = text[counter + 1:].strip()
    if not key:
        key = text[0] + text[0]
    return list(filter(None, [key, rest]))

def parser(text, keyword):
    if "buttonalert" in text:
        text = (text.replace("\n", "\\n").replace("\t", "\\t"))
    buttons = []
    note_data = ""
    prev = 0
    i = 0
    alerts = []
    for match in BTN_URL_REGEX.finditer(text):
        # Check if btnurl is escaped
        n_escapes = 0
        to_check = match.start(1) - 1
        while to_check > 0 and text[to_check] == "\\":
            n_escapes += 1
            to_check -= 1

        # if even, not escaped -> create button
        if n_escapes % 2 == 0:
            note_data += text[prev:match.start(1)]
            prev = match.end(1)
            if match.group(3) == "buttonalert":
                # create a thruple with button label, url, and newline status
                if bool(match.group(5)) and buttons:
                    buttons[-1].append(InlineKeyboardButton(
                        text=match.group(2),
                        callback_data=f"alertmessage:{i}:{keyword}"
                    ))
                else:
                    buttons.append([InlineKeyboardButton(
                        text=match.group(2),
                        callback_data=f"alertmessage:{i}:{keyword}"
                    )])
                i += 1
                alerts.append(match.group(4))
            elif bool(match.group(5)) and buttons:
                buttons[-1].append(InlineKeyboardButton(
                    text=match.group(2),
                    url=match.group(4).replace(" ", "")
                ))
            else:
                buttons.append([InlineKeyboardButton(
                    text=match.group(2),
                    url=match.group(4).replace(" ", "")
                )])

        else:
            note_data += text[prev:to_check]
            prev = match.start(1) - 1
    else:
        note_data += text[prev:]

    try:
        return note_data, buttons, alerts
    except:
        return note_data, buttons, None

def remove_escapes(text: str) -> str:
    res = ""
    is_escaped = False
    for counter in range(len(text)):
        if is_escaped:
            res += text[counter]
            is_escaped = False
        elif text[counter] == "\\":
            is_escaped = True
        else:
            res += text[counter]
    return res


def humanbytes(size):
    if not size:
        return ""
    power = 2**10
    n = 0
    Dic_powerN = {0: ' ', 1: 'Ki', 2: 'Mi', 3: 'Gi', 4: 'Ti'}
    while size > power:
        size /= power
        n += 1
    return str(round(size, 2)) + " " + Dic_powerN[n] + 'B'
